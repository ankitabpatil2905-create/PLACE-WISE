USE student_placement_db;
-- Additive change only: this does not drop or recreate your existing database.
CREATE TABLE IF NOT EXISTS Users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','student') NOT NULL,
  student_id INT NULL UNIQUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_users_student FOREIGN KEY (student_id)
    REFERENCES Student(student_id) ON DELETE SET NULL
);

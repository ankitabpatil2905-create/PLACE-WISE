STUDENT PLACEMENT MANAGEMENT SYSTEM
MySQL + MongoDB (SQL and NoSQL)

CONTENTS
1. mysql_student_placement.sql
   Complete MySQL database script: database creation, tables, constraints,
   sample data, three triggers, and example SQL queries.

2. mongodb_student_placement.js
   MongoDB collections, sample documents, indexes, CRUD operations,
   find queries, aggregation examples, and optional Atlas Trigger code.

HOW TO RUN MYSQL
1. Open MySQL Workbench and connect to your MySQL server.
2. Open mysql_student_placement.sql.
3. Execute the complete script.
4. Refresh Schemas and open student_placement_db.
5. Check Application, Placement, and Application_Audit after the sample
   UPDATE statement. The selected application should create a placement
   record and an audit record automatically.

HOW TO RUN MONGODB
1. Open MongoDB Compass and connect to your cluster/server.
2. Open a MongoDB Playground (or use mongosh).
3. Open mongodb_student_placement.js and run the commands.
4. Check the student_placement_nosql database and its collections.

PROJECT DESIGN
MySQL stores structured and related data such as students, companies,
placement drives, internships, skills, applications, placements, and audit
history. MongoDB stores flexible student profiles, skill arrays, company
documents, and application documents.

IMPORTANT NOTES
- The scripts are separate because MySQL SQL syntax and MongoDB shell
  syntax are different.
- The MongoDB Atlas Trigger is optional and must be configured in Atlas.
- The sample data is for academic demonstration. Change names, dates,
  and records if your project requires different data.
- The SQL CHECK constraints require a MySQL version that enforces CHECK
  constraints (MySQL 8.0.16 or later is recommended).
- Run the MySQL script in a test database: it begins by dropping
  student_placement_db if it already exists.

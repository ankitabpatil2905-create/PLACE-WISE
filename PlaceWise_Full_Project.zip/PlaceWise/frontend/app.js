
const $=s=>document.querySelector(s);
let me=null, students=[], companies=[], drives=[], internships=[], applications=[], placements=[];
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const pill=s=>`<span class="status ${(s||"Applied").toLowerCase()}">${esc(s)}</span>`;
const initials=n=>String(n||"?").split(" ").map(x=>x[0]).join("").slice(0,2).toUpperCase();
function toast(s){const t=$("#toast");if(t){t.textContent=s;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2500)}}
async function api(url,opts={}){const r=await fetch(url,{headers:{"Content-Type":"application/json",...(opts.headers||{})},...opts});let d=await r.json().catch(()=>({}));if(r.status===401){location.href="login.html";throw Error("Please sign in again.")}if(!r.ok)throw Error(d.error||"Request failed");return d}
async function init(){
 try{me=await api("/api/me");document.querySelector(".profile-mini b").textContent=me.email;document.querySelector(".profile-mini small").textContent=me.role+" account";document.querySelector(".avatar").textContent=initials(me.email);document.querySelector(".top-avatar").textContent=initials(me.email);
 if(me.role==="student"){document.querySelectorAll('[data-page="students"],[data-page="companies"]').forEach(x=>x.style.display="none");$("#addStudentBtn")?.remove();}
 await loadAll();
 }catch(e){location.href="login.html"}
}
async function loadAll(){
 [students,companies,drives,internships,applications,placements]=await Promise.all([
 api("/api/students"),api("/api/companies"),api("/api/drives"),api("/api/internships"),api("/api/applications"),api("/api/placements")
 ]);
 renderAll();
}
function renderAll(){
 const stats=document.querySelectorAll(".stat-card strong");
 if(stats.length>=4){stats[0].textContent=students.length;stats[1].textContent=drives.length+internships.length;stats[2].textContent=applications.length;stats[3].textContent=placements.length}
 $("#studentsTable").innerHTML=students.map(s=>`<tr><td><div class="student-cell"><div class="avatar">${initials(s.student_name)}</div><div><b>${esc(s.student_name)}</b><small>${esc(s.email)}</small></div></div></td><td>${esc(s.department)}</td><td>${Number(s.cgpa).toFixed(2)}</td><td>${s.graduation_year}</td><td>—</td><td>${pill(s.placement_status)}</td></tr>`).join("")||'<tr><td colspan="6">No students found.</td></tr>';
 $("#driveGrid").innerHTML=drives.map(d=>`<article class="drive-card"><div class="drive-card-top"><div class="company-logo">${initials(d.company_name)}</div><span class="soft-pill">${esc(d.drive_date)}</span></div><h3>${esc(d.drive_name)}</h3><p>${esc(d.company_name)} · ${esc(d.job_role)}</p><div class="drive-info"><div><span>Minimum CGPA</span><b>${d.min_cgpa}</b></div><div><span>Package</span><b>${d.package_lpa} LPA</b></div></div><button class="apply-btn" data-apply-drive="${d.drive_id}">Apply now</button></article>`).join("")||'<p>No placement drives available.</p>';
 $("#internshipGrid").innerHTML=internships.map(d=>`<article class="drive-card"><div class="company-logo">${initials(d.company_name)}</div><h3>${esc(d.internship_role)}</h3><p>${esc(d.company_name)}</p><div class="drive-info"><div><span>Minimum CGPA</span><b>${d.min_cgpa}</b></div><div><span>Monthly stipend</span><b>₹${d.stipend_monthly}</b></div></div><button class="apply-btn" data-apply-intern="${d.internship_id}">Apply now</button></article>`).join("")||'<p>No internships available.</p>';
 $("#applicationsTable").innerHTML=applications.map(a=>`<tr><td>#${a.application_id}</td><td>${esc(a.student_name)}</td><td><b>${esc(a.company_name)}</b><br><small>${esc(a.role)}</small></td><td>${esc(a.application_date)}</td><td>${a.package_lpa?`${a.package_lpa} LPA`:"—"}</td><td>${me.role==="admin"?`<select data-status="${a.application_id}"><option ${a.status==="Applied"?"selected":""}>Applied</option><option ${a.status==="Shortlisted"?"selected":""}>Shortlisted</option><option ${a.status==="Selected"?"selected":""}>Selected</option><option ${a.status==="Rejected"?"selected":""}>Rejected</option></select>`:pill(a.status)}</td></tr>`).join("")||'<tr><td colspan="6">No applications yet.</td></tr>';
 $("#placementsTable").innerHTML=placements.map(p=>`<tr><td>${esc(p.student_name)}</td><td>${esc(p.company_name)}</td><td>${esc(p.role)}</td><td>${p.package_lpa||"—"}</td><td>${esc(p.offer_date)}</td></tr>`).join("")||'<tr><td colspan="5">No placements recorded.</td></tr>';
 $("#companyGrid").innerHTML=companies.map(c=>`<article class="company-card"><div class="company-logo">${initials(c.company_name)}</div><div><h3>${esc(c.company_name)}</h3><p>${esc(c.industry)}</p></div></article>`).join("");
 $("#featuredDrives").innerHTML=drives.slice(0,3).map(d=>`<div class="opportunity"><div class="company-logo">${initials(d.company_name)}</div><div class="opp-main"><b>${esc(d.job_role)}</b><small>${esc(d.company_name)} · ${esc(d.drive_date)}</small></div><div class="opp-meta"><b>${d.package_lpa} LPA</b></div></div>`).join("");
 $("#recentActivity").innerHTML=applications.slice(0,4).map(a=>`<div class="activity"><i class="activity-dot"></i><div><b>${esc(a.company_name)} · ${esc(a.role)}</b><small>${esc(a.application_date)}</small><div>${pill(a.status)}</div></div></div>`).join("")||"No recent activity.";
}
function showPage(n){document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));$("#page-"+n)?.classList.add("active");document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===n));$("#crumbTitle").textContent=n[0].toUpperCase()+n.slice(1);$("#sidebar").classList.remove("open")}
document.addEventListener("click",async e=>{
 const n=e.target.closest("[data-page]");if(n)showPage(n.dataset.page);
 const g=e.target.closest("[data-goto]");if(g)showPage(g.dataset.goto);
 const ad=e.target.closest("[data-apply-drive]"), ai=e.target.closest("[data-apply-intern]");
 if(ad||ai){try{await api("/api/applications",{method:"POST",body:JSON.stringify(ad?{drive_id:Number(ad.dataset.applyDrive)}:{internship_id:Number(ai.dataset.applyIntern)})});toast("Application submitted.");await loadAll()}catch(x){toast(x.message)}}
});
document.addEventListener("change",async e=>{if(e.target.matches("[data-status]")){try{await api(`/api/applications/${e.target.dataset.status}`,{method:"PATCH",body:JSON.stringify({status:e.target.value})});toast("Application status updated.");await loadAll()}catch(x){toast(x.message)}}});
$("#menuBtn")?.addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
$("#modalClose")?.addEventListener("click",()=>$("#modalBackdrop").classList.remove("show"));
$("#helpBtn")?.addEventListener("click",()=>toast("Use the sidebar to explore placement information."));
$("#notificationBtn")?.addEventListener("click",()=>toast("You're all caught up."));
const logout=document.createElement("button");logout.className="outline-btn";logout.textContent="Log out";logout.style.marginLeft="12px";document.querySelector(".top-actions")?.append(logout);logout.onclick=async()=>{await api("/api/logout",{method:"POST"});location.href="login.html"};
init();

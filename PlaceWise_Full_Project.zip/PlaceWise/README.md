# PlaceWise — Student Placement Management System

This project uses your supplied HTML/CSS/JS dashboard and SQL/MongoDB files, with a Flask API and role-based login.

## What is included
- Original PlaceWise dashboard layout and stylesheet retained.
- Login page for Admin and Student.
- Student self-registration (only when the email already exists in the Student table).
- Secure password hashing and server-side sessions.
- Admin-only student list and application status updates.
- Database-backed companies, drives, internships, applications and placements.
- Server-side CGPA eligibility check and duplicate protection via your database indexes.
- Your original MySQL and MongoDB scripts copied into `database/`.

## Important database warning
Your original `mysql_student_placement.sql` starts with `DROP DATABASE IF EXISTS student_placement_db`. Running it again deletes and recreates that database. Back up any existing data first. If you already created the database and want to preserve it, do NOT rerun that script. Run only `database/mysql/users_addition.sql` to add login support.

## Setup (Windows / VS Code)
1. Install Python 3.10+ and MySQL 8.
2. Open this `PlaceWise` folder in VS Code.
3. Create and activate a virtual environment:
   ```powershell
   py -m venv .venv
   .venv\Scripts\Activate.ps1
   ```
4. Install dependencies:
   ```powershell
   pip install -r backend/requirements.txt
   ```
5. Copy `.env.example` to `.env` and fill in your local MySQL details. Keep `.env` private.
6. In MySQL Workbench:
   - If this is a fresh setup, review and run `database/mysql/mysql_student_placement.sql` once.
   - If your database already exists and has data, back it up and run only `database/mysql/users_addition.sql`.
7. Create the admin account:
   ```powershell
   python backend/create_admin.py
   ```
   Enter the admin email and password when prompted.
8. Start the website:
   ```powershell
   python backend/app.py
   ```
9. Open `http://127.0.0.1:5000`.

## Student registration
The student's email must already exist in the `Student` table. Admin should add the student record first. Students can then create their own account from the registration page.

## MongoDB
The original MongoDB script is preserved at `database/mongodb/mongodb_student_placement.js`. The current core application uses MySQL for relational placement transactions. MongoDB is not yet wired into the live Flask routes; use it for the flexible document/profile use cases described in your original MongoDB README/script. This avoids duplicating relational records or pretending a MongoDB integration is active when it is not.

## API overview
- `POST /api/login`, `POST /api/logout`, `GET /api/me`
- `POST /api/register`
- `GET /api/students` (admin)
- `POST /api/students` (admin)
- `GET /api/companies`
- `GET /api/drives`
- `GET /api/internships`
- `GET /api/applications`
- `POST /api/applications` (student)
- `PATCH /api/applications/<id>` (admin)
- `GET /api/placements`
- `GET /api/health`

## Current implementation scope
The core login, read views, student application submission, eligibility check, and admin application-status update routes are implemented. The original dashboard visual design is retained, but not every original demo control (such as all edit/delete flows and all admin create forms) has been connected yet. Treat this as a working first version to extend, not a fully production-hardened deployment.

## Security note
This is an academic local-development project. Before public deployment, use HTTPS, a strong random `SECRET_KEY`, secure cookie settings, CSRF protection, rate limiting, database least-privilege credentials, and production hosting configuration.

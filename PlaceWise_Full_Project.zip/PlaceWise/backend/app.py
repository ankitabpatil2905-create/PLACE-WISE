import os
from datetime import date
from functools import wraps
from flask import Flask, request, jsonify, session, send_from_directory
from flask_cors import CORS
import pymysql
from pymysql.cursors import DictCursor
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
load_dotenv(os.path.join(ROOT, ".env"))
app = Flask(__name__, static_folder=os.path.join(ROOT, "frontend"), static_url_path="")
app.secret_key = os.getenv("SECRET_KEY", "change-this-local-development-key")
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")
CORS(app, supports_credentials=True)

def db():
    return pymysql.connect(host=os.getenv("MYSQL_HOST","localhost"),
        user=os.getenv("MYSQL_USER","root"), password=os.getenv("MYSQL_PASSWORD",""),
        database=os.getenv("MYSQL_DATABASE","student_placement_db"),
        port=int(os.getenv("MYSQL_PORT","3306")), cursorclass=DictCursor,
        autocommit=False)

def query(sql, args=(), one=False):
    con=db()
    try:
        with con.cursor() as cur:
            cur.execute(sql,args)
            result=cur.fetchone() if one else cur.fetchall()
        con.commit()
        return result
    except Exception:
        con.rollback()
        raise
    finally: con.close()

def signed_in(fn):
    @wraps(fn)
    def wrapper(*a,**kw):
        if not session.get("user_id"): return jsonify(error="Please sign in."),401
        return fn(*a,**kw)
    return wrapper

def roles(*allowed):
    def deco(fn):
        @wraps(fn)
        @signed_in
        def wrapper(*a,**kw):
            if session.get("role") not in allowed: return jsonify(error="You do not have permission for this action."),403
            return fn(*a,**kw)
        return wrapper
    return deco

@app.get("/")
def home():
    if not session.get("user_id"): return send_from_directory(app.static_folder,"login.html")
    return send_from_directory(app.static_folder,"index.html")
@app.get("/login.html")
def login_page(): return send_from_directory(app.static_folder,"login.html")
@app.get("/register.html")
def register_page(): return send_from_directory(app.static_folder,"register.html")

@app.post("/api/register")
def register():
    data=request.get_json() or {}; email=(data.get("email") or "").strip().lower(); password=data.get("password") or ""
    if not email or len(password)<8: return jsonify(error="Enter a valid email and a password of at least 8 characters."),400
    student=query("SELECT student_id FROM Student WHERE LOWER(email)=%s",(email,),True)
    if not student: return jsonify(error="This email is not in the student database. Ask the admin to add your student record first."),404
    if query("SELECT user_id FROM Users WHERE email=%s",(email,),True): return jsonify(error="An account already exists for this email."),409
    query("INSERT INTO Users(email,password_hash,role,student_id) VALUES(%s,%s,'student',%s)",(email,generate_password_hash(password),student["student_id"]))
    return jsonify(message="Account created. You can now sign in.")

@app.post("/api/login")
def login():
    data=request.get_json() or {}; email=(data.get("email") or "").strip().lower(); password=data.get("password") or ""; role=data.get("role")
    user=query("SELECT user_id,email,password_hash,role,student_id FROM Users WHERE email=%s",(email,),True)
    if not user or not check_password_hash(user["password_hash"],password) or user["role"]!=role:
        return jsonify(error="Email, password or account type is incorrect."),401
    session.clear(); session.update(user_id=user["user_id"],email=user["email"],role=user["role"],student_id=user["student_id"])
    return jsonify(message="Signed in",role=user["role"])
@app.get("/api/me")
@signed_in
def me(): return jsonify(email=session["email"],role=session["role"],student_id=session.get("student_id"))
@app.post("/api/logout")
@signed_in
def logout(): session.clear(); return jsonify(message="Signed out")

@app.get("/api/students")
@roles("admin")
def students():
    return jsonify(query("""SELECT s.student_id,s.student_name,s.email,s.department,s.graduation_year,s.cgpa,s.placement_status
      FROM Student s ORDER BY s.student_name"""))
@app.post("/api/students")
@roles("admin")
def add_student():
    d=request.get_json() or {}
    required=["student_id","student_name","email","department","graduation_year","cgpa"]
    if any(d.get(k) in (None,"") for k in required): return jsonify(error="Fill all required student fields."),400
    query("INSERT INTO Student(student_id,student_name,email,department,graduation_year,cgpa) VALUES(%s,%s,%s,%s,%s,%s)",
      tuple(d[k] for k in required))
    return jsonify(message="Student added."),201

@app.get("/api/companies")
@signed_in
def companies(): return jsonify(query("SELECT company_id,company_name,website,industry FROM Company ORDER BY company_name"))
@app.get("/api/drives")
@signed_in
def drives():
    return jsonify(query("""SELECT d.drive_id,d.drive_name,d.job_role,d.min_cgpa,d.package_lpa,d.drive_date,c.company_name
    FROM Placement_Drive d JOIN Company c ON c.company_id=d.company_id ORDER BY d.drive_date"""))
@app.get("/api/internships")
@signed_in
def internships():
    return jsonify(query("""SELECT i.internship_id,i.internship_role,i.min_cgpa,i.stipend_monthly,i.start_date,c.company_name
    FROM Internship i JOIN Company c ON c.company_id=i.company_id ORDER BY i.start_date"""))
@app.get("/api/applications")
@roles("admin","student")
def applications():
    where=""; args=[]
    if session["role"]=="student": where="WHERE a.student_id=%s"; args=[session["student_id"]]
    return jsonify(query(f"""SELECT a.application_id,a.student_id,s.student_name,a.application_date,a.status,
      COALESCE(d.job_role,i.internship_role) AS role,c.company_name,d.package_lpa
      FROM Application a JOIN Student s ON s.student_id=a.student_id
      LEFT JOIN Placement_Drive d ON d.drive_id=a.drive_id
      LEFT JOIN Internship i ON i.internship_id=a.internship_id
      LEFT JOIN Company c ON c.company_id=COALESCE(d.company_id,i.company_id)
      {where} ORDER BY a.application_id DESC""",args))
@app.post("/api/applications")
@roles("student")
def apply():
    d=request.get_json() or {}; sid=session.get("student_id")
    drive_id=d.get("drive_id"); internship_id=d.get("internship_id")
    if bool(drive_id)==bool(internship_id): return jsonify(error="Choose exactly one opportunity."),400
    student=query("SELECT cgpa FROM Student WHERE student_id=%s",(sid,),True)
    if drive_id:
        item=query("SELECT min_cgpa FROM Placement_Drive WHERE drive_id=%s",(drive_id,),True)
        col="drive_id"; target=drive_id
    else:
        item=query("SELECT min_cgpa FROM Internship WHERE internship_id=%s",(internship_id,),True)
        col="internship_id"; target=internship_id
    if not item: return jsonify(error="Opportunity not found."),404
    if float(student["cgpa"])<float(item["min_cgpa"]): return jsonify(error=f"Not eligible. Minimum CGPA required: {item['min_cgpa']}."),400
    query(f"INSERT INTO Application(student_id,{col},application_date,status) VALUES(%s,%s,%s,'Applied')",(sid,target,date.today()))
    return jsonify(message="Application submitted."),201
@app.patch("/api/applications/<int:app_id>")
@roles("admin")
def update_application(app_id):
    status=(request.get_json() or {}).get("status")
    if status not in ["Applied","Shortlisted","Selected","Rejected"]: return jsonify(error="Invalid status."),400
    query("UPDATE Application SET status=%s WHERE application_id=%s",(status,app_id))
    return jsonify(message="Status updated.")
@app.get("/api/placements")
@roles("admin","student")
def placements():
    where=""; args=[]
    if session["role"]=="student": where="AND p.student_id=%s"; args=[session["student_id"]]
    return jsonify(query(f"""SELECT p.placement_id,s.student_name,c.company_name,
      COALESCE(d.job_role,i.internship_role) AS role,p.package_lpa,p.offer_date
      FROM Placement p JOIN Student s ON s.student_id=p.student_id JOIN Company c ON c.company_id=p.company_id
      LEFT JOIN Placement_Drive d ON d.drive_id=p.drive_id LEFT JOIN Internship i ON i.internship_id=p.internship_id
      WHERE 1=1 {where} ORDER BY p.offer_date DESC""",args))

@app.get("/api/health")
def health():
    try: query("SELECT 1",one=True); return jsonify(status="ok",mysql="connected")
    except Exception as e: return jsonify(status="error",message=str(e)),503

if __name__=="__main__":
    app.run(host="127.0.0.1",port=int(os.getenv("PORT","5000")),debug=True)

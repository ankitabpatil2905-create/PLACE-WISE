import os, getpass, pymysql
from dotenv import load_dotenv
from werkzeug.security import generate_password_hash
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),".."))
load_dotenv(os.path.join(ROOT,".env"))
email=input("Admin email: ").strip().lower()
password=getpass.getpass("Admin password (minimum 8 characters): ")
if len(password)<8: raise SystemExit("Password must be at least 8 characters.")
con=pymysql.connect(host=os.getenv("MYSQL_HOST","localhost"),user=os.getenv("MYSQL_USER","root"),
 password=os.getenv("MYSQL_PASSWORD",""),database=os.getenv("MYSQL_DATABASE","student_placement_db"))
try:
 with con.cursor() as c:
  c.execute("INSERT INTO Users(email,password_hash,role) VALUES(%s,%s,'admin')",
   (email,generate_password_hash(password)))
 con.commit()
 print("Admin account created.")
except Exception as e:
 con.rollback(); print("Could not create admin:",e)
finally: con.close()
